
#include "StatechartSignals.h"
#include "log_event.h"

#include "Strategy.h"
#include "StrategyImpl.h"
#include "Ctrl_modes.h"
#include "Ctrl_modesImpl.h"

void applicationStart(int qsize);

    extern StrategyImpl strategyImpl;
    extern Ctrl_modesImpl control_modesImpl;



