//
// Created by Sofie Haesaert on 9/23/17.
//

#ifndef TEST_HARNESS_C_ALICE_EXT_MEASURE_H
#define TEST_HARNESS_C_ALICE_EXT_MEASURE_H

#include <qf_port.h>
#include <qassert.h>

void meas_env(Ctrl_modesImpl *mepl);
#endif //TEST_HARNESS_C_ALICE_EXT_MEASURE_H
