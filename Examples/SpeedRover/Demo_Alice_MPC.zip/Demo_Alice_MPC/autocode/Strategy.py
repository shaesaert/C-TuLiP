#!/usr/bin/env python -i
#
# Copyright 2009, 2010 California Institute of Technology.
# ALL RIGHTS RESERVED. U.S. Government Sponsorship acknowledged.
#
"""
WARNING: This file was automatically generated - DO NOT HAND EDIT

File: Strategy.py

Automatically generated Strategy state machine trace GUI.
Date Created:  07-Oct-2009 16:07:24
Created By:    reder

GUI widget to trace the execution of state machine "Strategy".
"""
from Tkinter import *

if (sys.hexversion <= 0x010502f0):
    FIRST = 'first'

# Actual size of CASE window bound at code-generation time.
MAGICDRAW_WINDOW_WIDTH = 600.0
MAGICDRAW_WINDOW_HEIGHT = 500.0


class Strategy(object):
    """
    Build a simple trace GUI to follow state machine active states.
    Grid a canvas with scrollbars, and add zoom in and zoom out control buttons.
    Always follow the active state when zoomed.
    Drag mouse over an area to zoom to that area.
    """
    def __init__(self, name, wparam=972.0, hparam=436.0, parent=None, big_name=None, size=16):
        """
        Construct the basic widget
        """
        if parent == None:
            self.win = Tk()
            self.win.title(name)
        else:
            self.win = parent
                    
        # Font scaling id and zdepth value
        self.id = 0
        self.zdepth = 1.0        
        # Canvas creation
        self.canvas = Canvas(self.win, width=wparam, height=hparam, background='white')
        
        # Add scroll bars
        self.__addScrollBars(hparam,wparam)
        
        # Add zoom buttons
        self.__addZoomButtons()

        # Map state names to fill (outline?) colors:
        self.colorDict = {
                          'Pseudo0' : '#0000FF',
                          'Sinit' : '#FFFFCC',
                          's0' : '#FFFFCC',
                          's1' : '#FFFFCC',
                          's2' : '#FFFFCC',
                          's3' : '#FFFFCC',
                          's4' : '#FFFFCC',
                          's5' : '#FFFFCC',
                          's6' : '#FFFFCC',
                          's7' : '#FFFFCC',
                          's8' : '#FFFFCC',
                          's9' : '#FFFFCC',
                          's10' : '#FFFFCC',
                          's11' : '#FFFFCC',
                          's12' : '#FFFFCC',
                          's14' : '#FFFFCC',
                          's15' : '#FFFFCC',
                          's16' : '#FFFFCC',
                          's18' : '#FFFFCC',
                          's17' : '#FFFFCC'
                          }

        # Add a big title to the canvas widget that does not scale with zoom.
        if big_name != None:
            if big_name == True:
                self.label = Label(self.canvas, text=name, font=("Times", int(size), "bold"))
            else:
                self.label = Label(self.canvas, text=big_name, font=("Times", int(size), "bold"))
            self.label.pack()

        # State diagram elements:
        self.Pseudo0 = self.canvas.create_oval(100.0, 100.0, 118.0, 118.0, fill="#0000FF", tag="Pseudo0")
        self.Sinit = self.canvas.create_rectangle(140.0, 364.0, 250.0, 408.0, fill="#FFFFCC", width=2, outline="blue", tag="Sinit")
        self.sinitText = self.canvas.create_text(195.0, 369.0, text="Sinit", anchor=N, font=("Times", 12, "bold"))
        self.s0 = self.canvas.create_rectangle(140.0, 100.0, 250.0, 144.0, fill="#FFFFCC", width=2, outline="blue", tag="s0")
        self.s0Text = self.canvas.create_text(195.0, 105.0, text="s0", anchor=N, font=("Times", 12, "bold"))
        self.s1 = self.canvas.create_rectangle(305.0, 100.0, 415.0, 144.0, fill="#FFFFCC", width=2, outline="blue", tag="s1")
        self.s1Text = self.canvas.create_text(360.0, 105.0, text="s1", anchor=N, font=("Times", 12, "bold"))
        self.s2 = self.canvas.create_rectangle(470.0, 100.0, 580.0, 144.0, fill="#FFFFCC", width=2, outline="blue", tag="s2")
        self.s2Text = self.canvas.create_text(525.0, 105.0, text="s2", anchor=N, font=("Times", 12, "bold"))
        self.s3 = self.canvas.create_rectangle(635.0, 100.0, 745.0, 144.0, fill="#FFFFCC", width=2, outline="blue", tag="s3")
        self.s3Text = self.canvas.create_text(690.0, 105.0, text="s3", anchor=N, font=("Times", 12, "bold"))
        self.s4 = self.canvas.create_rectangle(140.0, 166.0, 250.0, 210.0, fill="#FFFFCC", width=2, outline="blue", tag="s4")
        self.s4Text = self.canvas.create_text(195.0, 171.0, text="s4", anchor=N, font=("Times", 12, "bold"))
        self.s5 = self.canvas.create_rectangle(305.0, 166.0, 415.0, 210.0, fill="#FFFFCC", width=2, outline="blue", tag="s5")
        self.s5Text = self.canvas.create_text(360.0, 171.0, text="s5", anchor=N, font=("Times", 12, "bold"))
        self.s6 = self.canvas.create_rectangle(470.0, 166.0, 580.0, 210.0, fill="#FFFFCC", width=2, outline="blue", tag="s6")
        self.s6Text = self.canvas.create_text(525.0, 171.0, text="s6", anchor=N, font=("Times", 12, "bold"))
        self.s7 = self.canvas.create_rectangle(635.0, 166.0, 745.0, 210.0, fill="#FFFFCC", width=2, outline="blue", tag="s7")
        self.s7Text = self.canvas.create_text(690.0, 171.0, text="s7", anchor=N, font=("Times", 12, "bold"))
        self.s8 = self.canvas.create_rectangle(140.0, 232.0, 250.0, 276.0, fill="#FFFFCC", width=2, outline="blue", tag="s8")
        self.s8Text = self.canvas.create_text(195.0, 237.0, text="s8", anchor=N, font=("Times", 12, "bold"))
        self.s9 = self.canvas.create_rectangle(305.0, 232.0, 415.0, 276.0, fill="#FFFFCC", width=2, outline="blue", tag="s9")
        self.s9Text = self.canvas.create_text(360.0, 237.0, text="s9", anchor=N, font=("Times", 12, "bold"))
        self.s10 = self.canvas.create_rectangle(470.0, 232.0, 580.0, 276.0, fill="#FFFFCC", width=2, outline="blue", tag="s10")
        self.s10Text = self.canvas.create_text(525.0, 237.0, text="s10", anchor=N, font=("Times", 12, "bold"))
        self.s11 = self.canvas.create_rectangle(635.0, 232.0, 745.0, 276.0, fill="#FFFFCC", width=2, outline="blue", tag="s11")
        self.s11Text = self.canvas.create_text(690.0, 237.0, text="s11", anchor=N, font=("Times", 12, "bold"))
        self.s12 = self.canvas.create_rectangle(140.0, 298.0, 250.0, 342.0, fill="#FFFFCC", width=2, outline="blue", tag="s12")
        self.s12Text = self.canvas.create_text(195.0, 303.0, text="s12", anchor=N, font=("Times", 12, "bold"))
        self.s14 = self.canvas.create_rectangle(305.0, 298.0, 415.0, 342.0, fill="#FFFFCC", width=2, outline="blue", tag="s14")
        self.s14Text = self.canvas.create_text(360.0, 303.0, text="s14", anchor=N, font=("Times", 12, "bold"))
        self.s15 = self.canvas.create_rectangle(470.0, 298.0, 580.0, 342.0, fill="#FFFFCC", width=2, outline="blue", tag="s15")
        self.s15Text = self.canvas.create_text(525.0, 303.0, text="s15", anchor=N, font=("Times", 12, "bold"))
        self.s16 = self.canvas.create_rectangle(635.0, 298.0, 745.0, 342.0, fill="#FFFFCC", width=2, outline="blue", tag="s16")
        self.s16Text = self.canvas.create_text(690.0, 303.0, text="s16", anchor=N, font=("Times", 12, "bold"))
        self.s18 = self.canvas.create_rectangle(305.0, 364.0, 415.0, 408.0, fill="#FFFFCC", width=2, outline="blue", tag="s18")
        self.s18Text = self.canvas.create_text(360.0, 369.0, text="s18", anchor=N, font=("Times", 12, "bold"))
        self.s17 = self.canvas.create_rectangle(470.0, 364.0, 580.0, 408.0, fill="#FFFFCC", width=2, outline="blue", tag="s17")
        self.s17Text = self.canvas.create_text(525.0, 369.0, text="s17", anchor=N, font=("Times", 12, "bold"))

        # Separator elements:

        # Transition diagram elements:
        self.tran0 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran1 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran2 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran3 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran4 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran5 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran6 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran7 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran8 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran9 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran10 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran11 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran12 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran13 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran14 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran15 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran16 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran17 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran18 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran19 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran20 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran21 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran22 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran23 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran24 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran25 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran26 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran27 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran28 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran29 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran30 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran31 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran32 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran33 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran34 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran35 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran36 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran37 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran38 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran39 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran40 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran41 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran42 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran43 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran44 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran45 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran46 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran47 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran48 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran49 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran50 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran51 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran52 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran53 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran54 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran55 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran56 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran57 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran58 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran59 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran60 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran61 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran62 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran63 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran64 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran65 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran66 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran67 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran68 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran69 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran70 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")
        self.tran71 = self.canvas.create_line(65.0, 104.0, 65.0, 64.0, width=2, arrow=FIRST, fill="red")

        # Text diagram elements:
        self.textBox0 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox1 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox2 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox3 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox4 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox5 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox6 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox7 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox8 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox9 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox10 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox11 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox12 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox13 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox14 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox15 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox16 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox17 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon0, freeway0_lidon1_stereo1_radon0, freeway0_lidon1_stereo1_radon1, freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox18 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox19 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox20 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox21 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon1, freeway1_lidon0_stereo0_radon1, freeway1_lidon0_stereo0_radon0, freeway0_lidon0_stereo0_radon0, freeway0_lidon1_stereo0_radon0, freeway1_lidon1_stereo0_radon0, freeway1_lidon1_stereo0_radon1, freeway0_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox22 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox23 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox24 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox25 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox26 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox27 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox28 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox29 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox30 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon1, freeway1_lidon0_stereo0_radon0, freeway1_lidon1_stereo0_radon0, freeway1_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox31 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox32 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon1, freeway1_lidon1_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox33 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox34 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox35 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox36 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox37 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox38 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox39 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway0_lidon0_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox40 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox41 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox42 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox43 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo1_radon0, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo0_radon0, freeway0_lidon1_stereo0_radon0, freeway0_lidon0_stereo1_radon1, freeway0_lidon0_stereo1_radon0, freeway0_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox44 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway0_lidon0_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox45 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox46 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox47 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox48 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon0, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway0_lidon0_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox49 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon1, freeway0_lidon0_stereo0_radon0, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox50 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox51 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox52 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway0_lidon0_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox53 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo0_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox54 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox55 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon1_stereo0_radon1, freeway0_lidon0_stereo0_radon0, freeway0_lidon1_stereo0_radon0, freeway0_lidon0_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox56 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox57 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox58 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox59 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway1_lidon1_stereo1_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox60 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox61 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo0_radon0, freeway1_lidon0_stereo0_radon1, freeway1_lidon1_stereo1_radon0, freeway1_lidon0_stereo1_radon0, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox62 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox63 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));
        self.textBox64 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox65 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon1, freeway1_lidon0_stereo0_radon0, freeway1_lidon1_stereo0_radon0, freeway1_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox66 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0, freeway0_lidon1_stereo1_radon1, freeway0_lidon0_stereo1_radon1, freeway0_lidon1_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox67 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway1_lidon0_stereo0_radon0, freeway1_lidon1_stereo0_radon1", anchor=NW, font=("Times", 11));
        self.textBox68 = self.canvas.create_text(100.0, 100.0, text="freeway0_lidon0_stereo1_radon0", anchor=NW, font=("Times", 11));
        self.textBox69 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon0_stereo1_radon0, freeway1_lidon0_stereo0_radon1, freeway0_lidon0_stereo0_radon1, freeway0_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon1, freeway1_lidon1_stereo0_radon0, freeway0_lidon1_stereo0_radon0", anchor=NW, font=("Times", 11));
        self.textBox70 = self.canvas.create_text(100.0, 100.0, text="freeway1_lidon1_stereo1_radon0, freeway1_lidon1_stereo1_radon1, freeway1_lidon0_stereo1_radon1", anchor=NW, font=("Times", 11));

        # Map state names to states:
        self.stateDict = {
                          'Pseudo0' : self.Pseudo0,
                          'Sinit' : self.Sinit,
                          's0' : self.s0,
                          's1' : self.s1,
                          's2' : self.s2,
                          's3' : self.s3,
                          's4' : self.s4,
                          's5' : self.s5,
                          's6' : self.s6,
                          's7' : self.s7,
                          's8' : self.s8,
                          's9' : self.s9,
                          's10' : self.s10,
                          's11' : self.s11,
                          's12' : self.s12,
                          's14' : self.s14,
                          's15' : self.s15,
                          's16' : self.s16,
                          's18' : self.s18,
                          's17' : self.s17
                          }

        # Map state names to states tag names:
        self.stateTagDict = {
                          'Pseudo0' : "Pseudo0",
                          'Sinit' : "Sinit",
                          's0' : "s0",
                          's1' : "s1",
                          's2' : "s2",
                          's3' : "s3",
                          's4' : "s4",
                          's5' : "s5",
                          's6' : "s6",
                          's7' : "s7",
                          's8' : "s8",
                          's9' : "s9",
                          's10' : "s10",
                          's11' : "s11",
                          's12' : "s12",
                          's14' : "s14",
                          's15' : "s15",
                          's16' : "s16",
                          's18' : "s18",
                          's17' : "s17"
                          }


    def ExitState(self, state):
        """
        Deactivate on exit
        """
        stateName = state.split(':')[0]
        self.canvas.itemconfigure(self.stateDict[stateName], width=2, outline= "blue")


    def EnterState(self, state):
        """
        Activate on entry
        """
        stateName = state.split(':')[0]
        self.canvas.itemconfigure(self.stateDict[stateName], width=4, outline = "green")
        self.moveActiveState(self.stateTagDict[stateName])
        
        
    def __addScrollBars(self, hparam, wparam):
        """
        Method to add scroll bars.
        """
        # Scroll bars:
        self.svert = Scrollbar(self.win, orient='vertical')
        self.shoriz = Scrollbar(self.win, orient='horizontal')
        # Grid the canvas and scrollbars here.
        self.canvas.grid(row=0, column=0, columnspan=3, sticky="NEWS")
        self.svert.grid(row=0, column=3, columnspan=1, sticky="NS")
        self.shoriz.grid(row=1, column=0, columnspan=3, sticky="EW")
    
        self.win.grid_columnconfigure(0, weight=1)
        self.win.grid_columnconfigure(1, weight=1)
        self.win.grid_columnconfigure(2, weight=1)

        self.win.grid_rowconfigure(0, weight=1)
        # Connect the canvas and scrollbars
        self.svert.config(command=self.canvas.yview)
        self.shoriz.config(command=self.canvas.xview)    
        self.canvas.config(xscrollcommand=self.shoriz.set)
        self.canvas.config(yscrollcommand=self.svert.set)
    
    
    def __addZoomButtons(self):
        """
        Method to add zoom buttons and mouse bindings.
        """        
        # Add a couple of zooming buttons
        self.factor = 1.1
        def zoomincb():
            self.zoom(self.factor)
        def zoomoutcb():
            self.zoom(1.0/self.factor)
        zoomin = Button(self.win, text="Zoom In", command=zoomincb)
        zoomout = Button(self.win, text="Zoom Out", command=zoomoutcb)
        zoomin.grid(row=2, column=0)
        zoomout.grid(row=2, column=1)

        # Set up event bindings for canvas
        self.canvas.bind("<1>", self.zoomMark)
        self.canvas.bind("<B1-Motion>", self.zoomStroke)
        self.canvas.bind("<ButtonRelease-1>", self.zoomArea)
    #-------------------------------------------------------
    #  activate rect.
    #-------------------------------------------------------
    def moveActiveState(self, state_tag):
        """
        Move the active state into the field of view of the window.
        """
        c = self.canvas
        region = c.cget('scrollregion')
        
        for i in c.find_all():
            if c.type(i) == "rectangle":
                # Find matching tag
                for tag in c.gettags(i):
                    if tag != "current" and tag == state_tag:
                        # Move to active state
                        c.config(scrollregion=c.bbox(tag))
                        # Bring back zoomed region
                        c.configure(scrollregion=region)
    #--------------------------------------------------------
    #  zoomMark
    #--------------------------------------------------------
    def zoomMark(self, event):
        """
        Mark the first (x,y) coordinate for zooming.
        """
        self.zoomArea = dict()
        x = event.x
        y = event.y
        self.zoomArea['x0'] = self.canvas.canvasx(x)
        self.zoomArea['y0'] = self.canvas.canvasy(y)
        self.canvas.create_rectangle(x, y, x, y, outline='black', tag="zoomArea")
    #--------------------------------------------------------
    #  zoomStroke
    #--------------------------------------------------------
    def zoomStroke(self, event):
        """
        Zoom in to the area selected by itemMark and itemStroke.
        """
        x = event.x
        y = event.y
        self.zoomArea['x1'] = self.canvas.canvasx(x)
        self.zoomArea['y1'] = self.canvas.canvasy(y)
        self.canvas.coords("zoomArea", self.zoomArea['x0'], self.zoomArea['y0'], self.zoomArea['x1'], self.zoomArea['y1'])
    #--------------------------------------------------------
    #  zoomArea
    #--------------------------------------------------------
    def zoomArea(self, event):
        """
        Zoom in to the area selected by itemMark and itemStroke.
        """
        x = event.x
        y = event.y
        #--------------------------------------------------------
        #  Get the final coordinates.
        #  Remove area selection rectangle
        #--------------------------------------------------------
        self.zoomArea['x1'] = self.canvas.canvasx(x)
        self.zoomArea['y1'] = self.canvas.canvasy(y)
        self.canvas.delete("zoomArea")
        #--------------------------------------------------------
        #  Check for zero-size area
        #--------------------------------------------------------
        if (self.zoomArea['x0'] == self.zoomArea['x1']) or (self.zoomArea['y0'] == self.zoomArea['y1']):
            return
        #--------------------------------------------------------
        #  Determine size and center of selected area
        #--------------------------------------------------------
        areaxlength = abs( self.zoomArea['x1'] - self.zoomArea['x0'] )
        areaylength = abs( self.zoomArea['y1'] - self.zoomArea['y0'] )
        xcenter = ( self.zoomArea['x0']+self.zoomArea['x1'] )/2.0
        ycenter = ( self.zoomArea['y0']+self.zoomArea['y1'] )/2.0
        #--------------------------------------------------------
        #  Determine size of current window view
        #  Note that canvas scaling always changes the coordinates
        #  into pixel coordinates, so the size of the current
        #  viewport is always the canvas size in pixels.
        #  Since the canvas may have been resized, ask the
        #  window manager for the canvas dimensions.
        #--------------------------------------------------------
        winxlength = self.canvas.winfo_width()
        winylength = self.canvas.winfo_height()
        #--------------------------------------------------------
        #  Calculate scale factors, and choose smaller
        #--------------------------------------------------------
        xscale = winxlength/areaxlength
        yscale = winylength/areaylength
        if (xscale > yscale):
            factor = yscale
        else:
            factor = xscale
        #--------------------------------------------------------
        #  Perform zoom operation
        #--------------------------------------------------------
        self.zoom(factor, xcenter, ycenter, winxlength, winylength)
    #------------------------------------------------------------
    # zoomText
    #------------------------------------------------------------
    def zoomtext(self, zdepth):
        """
        Adjust fonts
        """
        c = self.canvas
        for i in c.find_all():
            if c.type(i) != "text":
                continue
            fontsize = 0
            # get original fontsize and text from tags
            # if they were previously recorded
            for tag in c.gettags(i):
                if tag != "current":
                    if tag.find('_f') == 0:
                        fontsize = tag.strip("_f")
                    if tag.find('_t') == 0:
                        text     = tag.strip("_t")
            # if not, then record current fontsize and text
            # and use them
            font = c.itemcget(i,"font")
            if fontsize==0:
                text = c.itemcget(i,"text")
                fontsize = int(font.split()[1])
                c.addtag_withtag("_f%d" % fontsize,i)
                c.addtag_withtag("_t%s" % text,i)
            # scale font
            newsize = int(int(fontsize) * zdepth)
            #print fontsize, newsize, zdepth
            if abs(newsize) >= 4:
                newfont = "%s %d" % (font.split()[0],newsize)
                c.itemconfigure(i,font=newfont,text=text)
            else:
                c.itemconfigure(i,text="")
    #--------------------------------------------------------
    #  zoom
    #--------------------------------------------------------
    def zoom(self, factor, xcenter=None, ycenter=None, winxlength="", winylength=""):
        """
        Zoom the canvas view, based on scale factor
        and center point and size of new viewport.
        If the center point is not provided, zoom
        in/out on the current window center point.
    
        This procedure uses the canvas scale function to
        change coordinates of all objects in the canvas.
        """
        #print "factor = %f" % factor
        self.zdepth = self.zdepth*factor
        #--------------------------------------------------------
        #  If (xcenter, ycenter) were not supplied,
        #  get the canvas coordinates of the center
        #  of the current view.  Note that canvas
        #  size may have changed, so ask the window
        #  manager for its size.
        #--------------------------------------------------------
        if xcenter == None or ycenter == None:
            winxlength = self.canvas.winfo_width()
            winylength = self.canvas.winfo_height()
            xcenter = self.canvas.canvasx (winxlength/2.0)
            ycenter = self.canvas.canvasy (winylength/2.0)
        #print "winxlength, winylength = %d, %d" % (winxlength, winylength)
        #--------------------------------------------------------
        #  Scale all objects in the canvas
        #  Adjust our viewport center point
        #--------------------------------------------------------
        self.canvas.scale("all",0,0,factor,factor)
        xcenter = xcenter * factor
        ycenter = ycenter * factor
        #print "xcenter, ycenter = %7.2f, %7.2f" % (xcenter,ycenter)

        #--------------------------------------------------------
        #  Get the size of all the items on the canvas.
        #
        #  This is *really easy* using
        #      $canvas bbox all
        #  but it is also wrong.  Non-scalable canvas
        #  items like text and windows now have a different
        #  relative size when compared to all the lines and
        #  rectangles that were uniformly scaled with the
        #  [$canvas scale] command.
        #
        #  It would be better to tag all scalable items,
        #  and make a single call to [bbox].
        #  Instead, we iterate through all canvas items and
        #  their coordinates to compute our own bbox.
        #--------------------------------------------------------
        x0 = 1.0e30
        x1 = -1.0e30
        y0 = 1.0e30
        y1 = -1.0e30
        canvas = self.canvas
        for item in canvas.find_all():
            if canvas.type(item) == "arc":
                pass
            elif canvas.type(item) == "line":
                pass
            elif canvas.type(item) == "oval":
                pass
            elif canvas.type(item) == "polygon":
                pass
            elif canvas.type(item) == "rectangle":
                coords = canvas.coords(item)
                for i in range(0, len(coords), 2):
                    x = coords[i]
                    y = coords[i+1]
                    if x < x0:
                        x0 = x
                    if x > x1:
                        x1 = x
                    if y < y0:
                        y0 = y
                    if y > y1:
                        y1 = y

        #--------------------------------------------------------
        #  Now figure the size of the bounding box
        #--------------------------------------------------------
        xlength = x1-x0
        ylength = y1-y0

        #--------------------------------------------------------
        #  But ... if we set the scrollregion and xview/yview
        #  based on only the scalable items, then it is not
        #  possible to zoom in on one of the non-scalable items
        #  that is outside of the boundary of the scalable items.
        #
        #  So expand the [bbox] of scaled items until it is
        #  larger than [bbox all], but do so uniformly.
        #--------------------------------------------------------
        (ax0, ay0, ax1, ay1) = canvas.bbox("all")
        #print (ax0, ay0, ax1, ay1)
        while (ax0<x0) or (ay0<y0) or (ax1>x1) or (ay1>y1):
            # triple the scalable area size
            x0 = x0-xlength
            x1 = x1+xlength
            y0 = y0-ylength
            y1 = y1+ylength
            xlength = xlength*3.0
            ylength = ylength*3.0
        #print (x0, y0, x1, y1)
        #--------------------------------------------------------
        #  Now that we've finally got a region defined with
        #  the proper aspect ratio (of only the scalable items)
        #  but large enough to include all items, we can compute
        #  the xview/yview fractions and set our new viewport
        #  correctly.
        #--------------------------------------------------------
        newxleft = (xcenter-x0-(winxlength/2.0))/xlength
        newytop  = (ycenter-y0-(winylength/2.0))/ylength
        #print "xlength, ylength = %f,%f" % (xlength,ylength)
        #print newxleft,newytop
        canvas.configure(scrollregion = (x0,y0,x1,y1))
        canvas.xview_moveto(newxleft)
        canvas.yview_moveto(newytop)

        #
        # Scale the fonts
        def zoomt():
            self.zoomtext(self.zdepth)
        canvas.after_cancel(self.id)
        id = self.canvas.after_idle(zoomt)

        #--------------------------------------------------------
        #  Change the scroll region one last time, to fit the
        #  items on the canvas.
        #--------------------------------------------------------
        canvas.configure(scrollregion = canvas.bbox("all"))

# Test main to display the generated widget
if __name__ == "__main__":
    c = Strategy("Strategy Test",big_name=True)
    c.win.geometry('979x755+14+58')
    mainloop()
