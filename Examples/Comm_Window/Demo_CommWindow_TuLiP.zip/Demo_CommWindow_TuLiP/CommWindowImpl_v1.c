//===========================================================================
// This software contains Caltech/JPL confidential information.
//
// Copyright 2009-2017, by the California Institute of Technology.
// ALL RIGHTS RESERVED. United States Government Sponsorship Acknowledged.
// Any commercial use must be negotiated with the Office of Technology
// Transfer at the California Institute of Technology.
//
// This software may be subject to US export control laws and
// regulations. By accepting this document, the user agrees to comply
// with all applicable U.S. export laws and regulations, including the
// International Traffic and Arms Regulations, 22 C.F.R. 120-130 and the
// Export Administration Regulations, 15 C.F.R. 730-744. User has the
// responsibility to obtain export licenses, or other export authority as
// may be required before exporting such information to foreign countries
// or providing access to foreign persons.
//===========================================================================
//
//       File: CommWindowImpl.c
// Created on: 05-Jun-2017 18:01:15
//     Author: reder@jpl.nasa.gov
// SCACmdLine: -c -sm CommWindow -sm Elctra -sm SDST ../CommWindow.mdxml
//
// This file was stubbed by the JPL StateChart Autocoders, which converts UML
// Statecharts, in XML, to a C variant of Miro Samek's Quantum Framework.
//===========================================================================
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <log_event.h>
#include <qf_port.h>
#include <qassert.h>
#include <assert.h>
#include <CommWindowImpl.h>
#include <StatechartSignals.h>


int32_t CommWindowImpl_verbosity_level = 0;
// Comm window list
Node *head = NULL;

// Current time values for states to use
int current_start_time;
int current_duration_time;

//
// List functions here...
//

//
// Init. the empty list
//
void init(Node *head) {
    head = NULL;
}
//
// Is list empty
// returns 1 if the list is empty, otherwise returns 0
//
int isEmpty(Node *s) {
    return head == NULL ? 1 : 0;
};
//
//  push an times into stack
//
Node *push(Node *head, int ts, int td) {
    Node* tmp = (Node*)malloc(sizeof(Node));
    if(tmp == NULL)
    {
        exit(0);
    }
    tmp->start_time = ts;
    tmp->duration_time = td;
    tmp->next = head;
    head = tmp;
    return head;
};
//
//  pop an element from the stack
//
Node *pop(Node *s,int *ts, int *td) {
    Node* tmp = head;
    *ts = head->start_time;
    *td = head->duration_time;
    head = head->next;
    free(tmp);
    return head;
}
//
// display the stack content
//
void display(Node* head) {
    Node *current;
    current = head;
    if(current!= NULL)
    {
        printf("Times: ");
        do
        {
            printf("(%d, %d) ",current->start_time, current->duration_time);
            current = current->next;
        }
        while (current!= NULL);
        printf("\n");
    }
    else
    {
        printf("List is empty\n");
    }
}
//
// get the ts and td without pop off list
//
void top(Node *head, int *ts, int *td) {
    *ts = head->start_time;
    *td = head->duration_time;
    return;
}
//
// insert a new node at end of list with new time values
//
Node *insert_end(Node *head, int ts, int td) {
    Node *current;
    current = head;
    //
    // Create new node here...
    //
    Node* tmp = (Node*)malloc(sizeof(Node));
    if(tmp == NULL)
    {
        exit(0);
    }
    tmp->start_time = ts;
    tmp->duration_time = td;
    tmp->next = NULL;
    //
    // Advance to end of list and add new node here...
    //
    if(current!= NULL)
    {
        do
        {
            current = current->next;
        }
        while (current!= NULL);
        current->next = tmp;
    } else {
        // If empty just add it...
        head = tmp;
    }
    //
    return head;

}

// All the state machine Impl functions


CommWindowImpl *CommWindowImpl_Constructor (CommWindowImpl *mepl) {
    strncpy(mepl->machineName, "CommWindow", 128);
    mepl->machineName[128-1] = '\0';  // null-terminate to be sure

    AttributeMapper_init(mepl);
    
    init(head);

    return mepl;
}

void CommWindowImpl_set_qactive (CommWindowImpl *mepl, QActive *active) {
    mepl->active = active;
}

int32_t CommWindowImpl_get_verbosity () {
    return CommWindowImpl_verbosity_level;
}

/////////////////////////////////////////////////////
// Implement example communications window list here
/////////////////////////////////////////////////////


////////////////////////////////////////////
// Action and guard implementation methods
////////////////////////////////////////////

void CommWindowImpl_insertTable (CommWindowImpl *mepl, QEvent const* e) {
    int ts, td;
    DataEvent *de = (DataEvent *)e;
    printf("%s.insertTable() default action implementation invoked\n", mepl->machineName);
    ts = de->start_time;
    td = de->duration_time;
    printf("start_time=%d duration_time=%d (in ticks units)\n", ts, td);
    head = insert_end(head, ts, td);
}

void CommWindowImpl_isEmptyList (CommWindowImpl *mepl) {
    QEvent *newEv;
    printf("%s.isEmptyList() default action implementation invoked\n", mepl->machineName);
    if( isEmpty(head) == 1 ) {
        printf("Comm window list is empty!\n");
    } else {
        printf("Publish a GO_WAIT event since list is not empty.\n");
        newEv = Q_NEW(QEvent, GO_WAIT_SIG);
        QF_publish(newEv);
    }
}

void CommWindowImpl_startDurationTimer (CommWindowImpl *mepl) {
    printf("%s.startDurationTimer() default action implementation invoked\n", mepl->machineName);
    head = pop(head, &current_start_time, &current_duration_time);
    printf("current_start_time = %d, current_duration_time = %d\n", current_start_time, current_duration_time);
    fflush(stdout);
}

void CommWindowImpl_startTimer (CommWindowImpl *mepl) {
    printf("%s.startTimer() default action implementation invoked\n", mepl->machineName);
    top(head, &current_start_time, &current_duration_time);
    printf("current_start_time = %d, current_duration_time = %d\n", current_start_time, current_duration_time);
    fflush(stdout);
}

void CommWindowImpl_updateDurationTimer (CommWindowImpl *mepl) {
    QEvent *newEv;
    printf("%s.updateDurationTimer() default action implementation invoked\n", mepl->machineName);
    printf("current_duration_time = %d\n", current_duration_time);
    current_duration_time--;
    if(current_duration_time == 0) {
        printf("Publish a TIMEOUT event since duration time is zero.\n");
        newEv = Q_NEW(QEvent, TIMEOUT_SIG);
        QF_publish(newEv);
    }
    fflush(stdout);
}

void CommWindowImpl_updateTimer (CommWindowImpl *mepl) {
    QEvent *newEv;
    printf("%s.updateTimer() default action implementation invoked\n", mepl->machineName);
    printf("current_start_time = %d\n", current_start_time);
    current_start_time--;
    if(current_start_time == 0) {
        printf("Publish a TIMEOUT event since start time is zero.\n");
        newEv = Q_NEW(QEvent, TIMEOUT_SIG);
        QF_publish(newEv);
    }
    fflush(stdout);
}
