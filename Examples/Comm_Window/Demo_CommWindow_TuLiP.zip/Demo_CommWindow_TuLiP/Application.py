
import sys
sys.path.append('autocode')

import CommWindow
import Elctra
import SDST

def update():
    cmWindow.win.update()
    elt.win.update()
    sdst.win.update()

cmWindow = CommWindow.CommWindow("cmWindow:CommWindow")
cmWindow.canvas.scale("all", 0.0, 0.0, 1.00, 1.00)
cmWindow.win.geometry('979x755+14+58')
elt = Elctra.Elctra("elt:Elctra")
elt.canvas.scale("all", 0.0, 0.0, 1.00, 1.00)
elt.win.geometry('979x755+14+58')
sdst = SDST.SDST("sdst:SDST")
sdst.canvas.scale("all", 0.0, 0.0, 1.00, 1.00)
sdst.win.geometry('979x755+14+58')


mapCharts = {

    'cmWindow:CommWindow': cmWindow,
    'elt:Elctra': elt,
    'sdst:SDST': sdst,

}
