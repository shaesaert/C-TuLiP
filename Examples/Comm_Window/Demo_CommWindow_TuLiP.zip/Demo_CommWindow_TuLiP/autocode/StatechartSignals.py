#!/tps/bin/python
# GUI application to issue signals to a state machine.
#
from Tkinter import *

class StatechartSignals:
    """
    """
    def __init__(self, clientSocket):
        self.clientSocket = clientSocket
        win = Tk()
        # Grid sizing behavior for this window
        win.grid_rowconfigure(1, weight=1)
        win.grid_columnconfigure(0, weight=1)
        label = Label(win, text = "Statechart Signals", font = ("Times", 16, "bold"))
        label.grid(row=0, column=0, sticky='ew')
        # Canvas
        cnv = Canvas(win)
        cnv.grid(row=1, column=0, sticky='nswe')
        # vertical scrollbar for the canvas
        vScroll = Scrollbar(win, orient=VERTICAL, command=cnv.yview)
        vScroll.grid(row=1, column=1, sticky='ns')
        cnv.configure(yscrollcommand=vScroll.set)
        # Frame in canvas
        frm = Frame(cnv)
        # This puts the frame in the canvas's scrollable zone
        cnv.create_window(0, 0, window=frm, anchor='nw')

        callback = ButtonCallback(self.doButton, "4")
        b4 = Button(frm, text = "Tick", command=callback)
        b4.pack()
        callback = ButtonCallback(self.doButton, "5")
        b5 = Button(frm, text = "ABORT", command=callback)
        b5.pack()
        callback = ButtonCallback(self.doButton, "6")
        b6 = Button(frm, text = "ADD_WINDOW", command=callback)
        b6.pack()
        callback = ButtonCallback(self.doButton, "7")
        b7 = Button(frm, text = "ELCTRA_RADIO_OFF", command=callback)
        b7.pack()
        callback = ButtonCallback(self.doButton, "8")
        b8 = Button(frm, text = "ELCTRA_RADIO_ON", command=callback)
        b8.pack()
        callback = ButtonCallback(self.doButton, "9")
        b9 = Button(frm, text = "ELT_OFF", command=callback)
        b9.pack()
        callback = ButtonCallback(self.doButton, "10")
        b10 = Button(frm, text = "ELT_ON", command=callback)
        b10.pack()
        callback = ButtonCallback(self.doButton, "11")
        b11 = Button(frm, text = "GO_WAIT", command=callback)
        b11.pack()
        callback = ButtonCallback(self.doButton, "12")
        b12 = Button(frm, text = "RTI", command=callback)
        b12.pack()
        callback = ButtonCallback(self.doButton, "13")
        b13 = Button(frm, text = "SDST_OFF", command=callback)
        b13.pack()
        callback = ButtonCallback(self.doButton, "14")
        b14 = Button(frm, text = "SDST_ON", command=callback)
        b14.pack()
        callback = ButtonCallback(self.doButton, "15")
        b15 = Button(frm, text = "SDST_RADIO_OFF", command=callback)
        b15.pack()
        callback = ButtonCallback(self.doButton, "16")
        b16 = Button(frm, text = "SDST_RADIO_ON", command=callback)
        b16.pack()
        callback = ButtonCallback(self.doButton, "17")
        b17 = Button(frm, text = "TIMEOUT", command=callback)
        b17.pack()
        callback = ButtonCallback(self.doButton, "18")
        b18 = Button(frm, text = "transmit_False_cfg_False_idle_False_cln_True", command=callback)
        b18.pack()
        callback = ButtonCallback(self.doButton, "19")
        b19 = Button(frm, text = "transmit_False_cfg_False_idle_True_cln_False", command=callback)
        b19.pack()
        callback = ButtonCallback(self.doButton, "20")
        b20 = Button(frm, text = "transmit_False_cfg_True_idle_False_cln_False", command=callback)
        b20.pack()
        callback = ButtonCallback(self.doButton, "21")
        b21 = Button(frm, text = "transmit_True_cfg_False_idle_False_cln_False", command=callback)
        b21.pack()

        # Update display to get correct dimensions
        frm.update_idletasks()
        # Configure size of frmvas's scrollable zone
        cnv.configure(scrollregion=(0, 0, frm.winfo_width(), frm.winfo_height()))


    def doButton(self,enumValue):
        """
        """
        enumValue = enumValue + "\n"
        self.clientSocket.send(enumValue)


class ButtonCallback:
    """
    """
    def __init__(self, callback, *firstArgs):
        """
        """
        self.__callback = callback
        self.__firstArgs = firstArgs

    def __call__(self, *args):
        """
        """
        return apply(self.__callback, self.__firstArgs + args)
