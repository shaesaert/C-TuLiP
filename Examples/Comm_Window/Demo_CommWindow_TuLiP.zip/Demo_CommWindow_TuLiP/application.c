

#include "qep_port.h"
#include "application.h"
#include "qassert.h"

#include <termios.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>


#define MYQUEUESIZE 10

  CommWindowImpl cmWindowImpl;
  CommWindow cmWindow;
  const QEvent * cmWindow_queuestorage[MYQUEUESIZE];
  ElctraImpl eltImpl;
  Elctra elt;
  const QEvent * elt_queuestorage[MYQUEUESIZE];
  SDSTImpl sdstImpl;
  SDST sdst;
  const QEvent * sdst_queuestorage[MYQUEUESIZE];
  
void applicationStart(int qsize)
{

  CommWindowImpl_Constructor(&cmWindowImpl);
  CommWindow_Constructor(&cmWindow, "cmWindow", &cmWindowImpl, 0);
  QActive_start((QActive *) & cmWindow, 1, cmWindow_queuestorage,  MYQUEUESIZE, NULL, 0, NULL);
  ElctraImpl_Constructor(&eltImpl);
  Elctra_Constructor(&elt, "elt", &eltImpl, 0);
  QActive_start((QActive *) & elt, 2, elt_queuestorage,  MYQUEUESIZE, NULL, 0, NULL);
  SDSTImpl_Constructor(&sdstImpl);
  SDST_Constructor(&sdst, "sdst", &sdstImpl, 0);
  QActive_start((QActive *) & sdst, 3, sdst_queuestorage,  MYQUEUESIZE, NULL, 0, NULL);

}

////////////////////////////////////////////////////////////////////////////////
//@fn setGuardAttribute()
//@brief 
//@param 
//@return 
////////////////////////////////////////////////////////////////////////////////
void setGuardAttribute (const char *sm, const char *attr, const char *val) {
	printf("Got sm '%s', attr name '%s', and value '%s'\n", sm, attr, val);
	
	if (strcasecmp(sm, "cmWindow") == 0) {
	   AttributeMapper_set(&(cmWindowImpl), attr, AttributeMapper_strtobool(val));
	}
	if (strcasecmp(sm, "elt") == 0) {
	   AttributeMapper_set(&(eltImpl), attr, AttributeMapper_strtobool(val));
	}
	if (strcasecmp(sm, "sdst") == 0) {
	   AttributeMapper_set(&(sdstImpl), attr, AttributeMapper_strtobool(val));
	}
}
