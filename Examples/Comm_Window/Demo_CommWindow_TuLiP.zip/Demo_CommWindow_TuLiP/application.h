
#include "StatechartSignals.h"
#include "log_event.h"

#include "CommWindow.h"
#include "CommWindowImpl.h"
#include "Elctra.h"
#include "ElctraImpl.h"
#include "SDST.h"
#include "SDSTImpl.h"

void applicationStart(int qsize);

    extern CommWindowImpl cmWindowImpl;
    extern ElctraImpl eltImpl;
    extern SDSTImpl sdstImpl;



